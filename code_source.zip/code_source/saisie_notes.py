from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTableWidget, QPushButton, QTableWidgetItem,
                             QHeaderView, QMessageBox)
from PyQt5.QtCore import Qt
from database import get_db_connection

class SaisieNotesTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.table = QTableWidget()
        self.table.setColumnCount(14)
        self.table.setHorizontalHeaderLabels([
            "N° Table", "Anonymat", "EPS", "Compo. Française", "Dictée", "Etude de texte",
            "SVT", "Anglais 1", "Mathématiques", "Histoire-Géo", 
            "Instruction Civique", "PC/LV2", "Anglais (Oral)",
            "Epreuve Facultative"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        save_button = QPushButton("Enregistrer les notes")
        save_button.clicked.connect(self.save_notes)
        layout.addWidget(save_button)

        self.setLayout(layout)
        self.load_notes()

    def load_notes(self):
        conn = get_db_connection()
        c = conn.cursor()
        c.execute('''
            SELECT Candidat.Numero_Table, Candidat.Anonymat, 
                   Notes.EPS, Notes.Compo_Franc, Notes.Dictee, Notes.Etude_de_texte, 
                   Notes.SVT, Notes.Anglais1, Notes.Mathematiques, Notes.Histoire_Geographie, 
                   Notes.Instruction_Civique, Notes.PC_LV2, Notes.Anglais_Oral, Notes.Epreuve_Facultative
            FROM Candidat 
            LEFT JOIN Notes ON Candidat.Numero_Table = Notes.Numero_Table
            ORDER BY Candidat.Numero_Table
        ''')
        notes = c.fetchall()
        conn.close()

        self.table.setRowCount(len(notes))
        for row, note in enumerate(notes):
            for col, value in enumerate(note):
                item = QTableWidgetItem(str(value) if value is not None else "")
                if col < 2:  # Numéro de table et Anonymat non modifiables
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.table.setItem(row, col, item)

    def save_notes(self):
        conn = get_db_connection()
        c = conn.cursor()
        
        for row in range(self.table.rowCount()):
            numero_table = self.table.item(row, 0).text()
            notes = [self.table.item(row, col).text() for col in range(2, 14)]
            
            c.execute('''
                UPDATE Notes 
                SET EPS=?, Compo_Franc=?, Dictee=?, Etude_de_texte=?, SVT=?, Anglais1=?,
                    Mathematiques=?, Histoire_Geographie=?, Instruction_Civique=?, PC_LV2=?,
                    Anglais_Oral=?, Epreuve_Facultative=?
                WHERE Numero_Table=?
            ''', (*notes, numero_table))
        
        conn.commit()
        conn.close()
        
        QMessageBox.information(self, "Succès", "Toutes les notes ont été enregistrées")

    def showEvent(self, event):
        super().showEvent(event)
        self.load_notes()