from PyQt5.QtWidgets import QMainWindow, QTabWidget
from parametrage_jury import ParametrageJuryTab
from gestion_candidats import GestionCandidatsTab
from saisie_notes import SaisieNotesTab
from deliberation import DeliberationTab
from statistiques import StatistiquesTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestion BFEM")
        self.setGeometry(100, 100, 1000, 800)

        self.tab_widget = QTabWidget()
        self.setCentralWidget(self.tab_widget)

        self.tab_widget.addTab(ParametrageJuryTab(), "Paramétrage du Jury")
        self.tab_widget.addTab(GestionCandidatsTab(), "Gestion des Candidats")
        self.tab_widget.addTab(SaisieNotesTab(), "Saisie des Notes")
        self.tab_widget.addTab(DeliberationTab(), "Délibération")
        self.tab_widget.addTab(StatistiquesTab(), "Statistiques")