
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt5.QtCore import Qt
from database import get_db_connection
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from pdf_generator import (generer_liste_candidats, generer_liste_anonymats, generer_resultats,
                           generer_pv_deliberations, generer_releve_notes_individuel)

class StatistiquesTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.stats_label = QLabel()
        self.stats_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.stats_label)

        self.figure = plt.figure(figsize=(10, 5))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        refresh_button = QPushButton("Rafraîchir les statistiques")
        refresh_button.clicked.connect(self.update_stats)
        layout.addWidget(refresh_button)

        generate_candidates_button = QPushButton("Générer liste des candidats")
        generate_candidates_button.clicked.connect(generer_liste_candidats)
        layout.addWidget(generate_candidates_button)

        generate_anonymats_button = QPushButton("Générer liste des anonymats")
        generate_anonymats_button.clicked.connect(generer_liste_anonymats)
        layout.addWidget(generate_anonymats_button)

        generate_notes_1st_tour_button = QPushButton("Générer relevés de notes 1er tour")
        generate_notes_1st_tour_button.clicked.connect(lambda: generer_releve_notes_individuel(1))
        layout.addWidget(generate_notes_1st_tour_button)

        generate_notes_2nd_tour_button = QPushButton("Générer relevés de notes 2nd tour")
        generate_notes_2nd_tour_button.clicked.connect(lambda: generer_releve_notes_individuel(2))
        layout.addWidget(generate_notes_2nd_tour_button)

        generate_results_button = QPushButton("Générer résultats")
        generate_results_button.clicked.connect(generer_resultats)
        layout.addWidget(generate_results_button)

        generate_pv_button = QPushButton("Générer PV de délibérations")
        generate_pv_button.clicked.connect(generer_pv_deliberations)
        layout.addWidget(generate_pv_button)



        self.setLayout(layout)
        self.update_stats()

    def update_stats(self):
        conn = get_db_connection()
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM Candidat")
        total_candidats = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM Candidat WHERE Sexe='M'")
        total_hommes = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM Candidat WHERE Sexe='F'")
        total_femmes = c.fetchone()[0]
        
        c.execute("SELECT Decision, COUNT(*) FROM Deliberation GROUP BY Decision")
        resultats = dict(c.fetchall())
        
        conn.close()

        stats_text = f"""
        Total des candidats: {total_candidats}
        Hommes: {total_hommes}
        Femmes: {total_femmes}
        
        Résultats:
        Admis: {resultats.get('Admis', 0)}
        Second Tour: {resultats.get('Second Tour', 0)}
        Repêchables: {resultats.get('Repêchable', 0) + resultats.get('Repêchable (2nd Tour)', 0)}
        Echecs: {resultats.get('Echec', 0)}
        """
        
        self.stats_label.setText(stats_text)

        # Création du graphique
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        labels = ['Admis', 'Second Tour', 'Repêchables', 'Echecs']
        sizes = [resultats.get('Admis', 0),
                resultats.get('Second Tour', 0),
                resultats.get('Repêchable', 0) + resultats.get('Repêchable (2nd Tour)', 0),
                resultats.get('Echec', 0)]
        
        # Vérifier si toutes les valeurs sont zéro
        if sum(sizes) == 0:
            ax.text(0.5, 0.5, 'Pas de données disponibles', ha='center', va='center')
            ax.axis('off')
        else:
            # Filtrer les labels et sizes pour exclure les valeurs nulles
            non_zero = [(label, size) for label, size in zip(labels, sizes) if size > 0]
            if non_zero:
                labels, sizes = zip(*non_zero)
                ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
                ax.axis('equal')
            else:
                ax.text(0.5, 0.5, 'Pas de données non nulles disponibles', ha='center', va='center')
                ax.axis('off')
        
        ax.set_title('Répartition des résultats')
        
        self.canvas.draw()