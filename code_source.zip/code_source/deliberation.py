from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTableWidget, QPushButton, QTableWidgetItem,
                             QHeaderView, QMessageBox, QDialog, QFormLayout, QLineEdit, QHBoxLayout)
from PyQt5.QtCore import Qt
from database import get_db_connection


class DeliberationTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["N° Table", "Nom", "Prénom(s)", "Total Points",
                                              "Moyenne", "Décision", "Actions"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        deliberer_button = QPushButton("Délibérer")
        deliberer_button.clicked.connect(self.deliberer)
        layout.addWidget(deliberer_button)

        self.setLayout(layout)

    def deliberer(self):
        conn = get_db_connection()
        c = conn.cursor()

        c.execute('''SELECT Candidat.Numero_Table, Candidat.Nom, Candidat.Prenom_s, Notes.*,
                            Livret_Scolaire.Moyenne_Cycle, Livret_Scolaire.Nombre_de_fois
                     FROM Candidat
                     LEFT JOIN Notes ON Candidat.Numero_Table = Notes.Numero_Table
                     LEFT JOIN Livret_Scolaire ON Candidat.Numero_Table = Livret_Scolaire.Numero_Table''')
        resultats = c.fetchall()

        self.table.setRowCount(len(resultats))
        for row, resultat in enumerate(resultats):
            numero_table, nom, prenom, *notes, moyenne_cycle, nombre_fois = resultat

            # Si moyenne_cycle ou nombre_fois sont None, on leur attribue une valeur par défaut
            moyenne_cycle = moyenne_cycle if moyenne_cycle is not None else 0
            nombre_fois = nombre_fois if nombre_fois is not None else 0

            total_points = self.calculer_total_points(notes)
            moyenne = (total_points/18) # 20 est le total des coefficients
            decision = self.prendre_decision(total_points, moyenne_cycle, nombre_fois)

            self.table.setItem(row, 0, QTableWidgetItem(str(numero_table)))
            self.table.setItem(row, 1, QTableWidgetItem(nom))
            self.table.setItem(row, 2, QTableWidgetItem(prenom))
            self.table.setItem(row, 3, QTableWidgetItem(f"{total_points:.2f}"))
            self.table.setItem(row, 4, QTableWidgetItem(f"{moyenne:.2f}"))
            self.table.setItem(row, 5, QTableWidgetItem(decision))

            if decision == "Second Tour":
                second_tour_button = QPushButton("Saisir notes 2nd tour")
                second_tour_button.clicked.connect(lambda _, r=row: self.saisir_notes_second_tour(r))
                self.table.setCellWidget(row, 6, second_tour_button)

        conn.close()
        QMessageBox.information(self, "Succès", "Délibération terminée")

    def calculer_total_points(self, notes):
        coefficients = [2, 1, 1, 1, 2, 4, 2, 2, 2, 1, 1, 1]
        notes = notes[1:13]  # Prend seulement les 12 premières valeurs
        print(notes)
        notes = [note if note is not None else 0 for note in notes]  # Remplace None par 0

        total = sum(note * coef for note, coef in zip(notes, coefficients))

        # Gestion du bonus/malus EPS
        if len(notes) > 10 and notes[10] is not None:
            total += (notes[10] - 10) if notes[10] > 10 else -(10 - notes[10])

        # Gestion du bonus épreuve facultative
        if len(notes) > 11 and notes[11] is not None and notes[11] > 10:
            total += notes[11] - 10

        return total

    def prendre_decision(self, total_points, moyenne_cycle, nombre_fois):
        if total_points >= 180 or (total_points >= 171 and moyenne_cycle >= 12 and nombre_fois >= 2):
            return "Admis"
        elif total_points >= 153 or (total_points >= 144 and moyenne_cycle >= 12 and nombre_fois > 2):
            return "Second Tour"
        elif total_points < 153:
            return "Ajourner"

    def saisir_notes_second_tour(self, row):
        numero_table = self.table.item(row, 0).text()
        dialog = NotesSecondTourDialog(self, numero_table)
        if dialog.exec_():
            self.deliberer()  # Relancer la délibération après la saisie des notes du second tour


class NotesSecondTourDialog(QDialog):
    def __init__(self, parent=None, numero_table=None):
        super().__init__(parent)
        self.setWindowTitle("Saisie des notes du second tour")
        layout = QFormLayout()

        self.numero_table = numero_table
        self.francais_input = QLineEdit()
        self.mathematiques_input = QLineEdit()
        self.pc_lv2_input = QLineEdit()

        layout.addRow("Français:", self.francais_input)
        layout.addRow("Mathématiques:", self.mathematiques_input)
        layout.addRow("PC/LV2:", self.pc_lv2_input)

        buttons = QHBoxLayout()
        save_button = QPushButton("Enregistrer")
        save_button.clicked.connect(self.save_notes)
        cancel_button = QPushButton("Annuler")
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addRow(buttons)

        self.setLayout(layout)

    def save_notes(self):
        try:
            francais = float(self.francais_input.text())
            mathematiques = float(self.mathematiques_input.text())
            pc_lv2 = float(self.pc_lv2_input.text())
        except ValueError:
            QMessageBox.warning(self, "Erreur", "Veuillez entrer des notes valides")
            return

        conn = get_db_connection()
        c = conn.cursor()
        c.execute('''INSERT OR REPLACE INTO Notes_Second_Tour 
                     (Numero_Table, Francais, Mathematiques, PC_LV2)
                     VALUES (?, ?, ?, ?)''',
                  (self.numero_table, francais, mathematiques, pc_lv2))
        conn.commit()
        conn.close()

        self.accept()