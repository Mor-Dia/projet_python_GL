from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTableWidget, QPushButton, QHBoxLayout,
                             QTableWidgetItem, QDialog, QFormLayout, QLineEdit, QDateEdit,
                             QComboBox, QCheckBox, QMessageBox)
from PyQt5.QtCore import Qt, QRegExp, QDate
from PyQt5.QtGui import QRegExpValidator
from database import get_db_connection
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog

import random
import string
import openpyxl
from datetime import datetime

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTableWidget, QPushButton, QHBoxLayout,
                             QTableWidgetItem, QDialog, QFormLayout, QLineEdit, QDateEdit,
                             QComboBox, QCheckBox, QMessageBox, QFileDialog, QHeaderView)
from PyQt5.QtCore import Qt, QRegExp, QDate
from PyQt5.QtGui import QRegExpValidator
from database import get_db_connection
import random
import string
import openpyxl
from datetime import datetime


class GestionCandidatsTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Rechercher un candidat...")
        self.search_input.textChanged.connect(self.filter_candidates)
        layout.addWidget(self.search_input)

        self.table = QTableWidget()
        self.table.setColumnCount(17)
        self.table.setHorizontalHeaderLabels([
            "N° Table", "Prénom(s)", "Nom", "Date Naissance", "Lieu Naissance", "Sexe",
            "Nationalité", "Nb fois", "Etat Sportif", "Epreuve Facultative",
            "Moy 6e", "Moy 5e", "Moy 4e", "Moy 3e", "Moy Cycle", "Anonymat", "Actions"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        button_layout = QHBoxLayout()
        add_button = QPushButton("Ajouter")
        sup_button = QPushButton("Supprimer")
        edit_button = QPushButton("Modifier")
        import_button = QPushButton("Importer Excel")
        button_layout.addWidget(add_button)
        button_layout.addWidget(sup_button)
        button_layout.addWidget(edit_button)
        button_layout.addWidget(import_button)

        layout.addLayout(button_layout)

        self.setLayout(layout)

        add_button.clicked.connect(self.add_candidat)
        sup_button.clicked.connect(self.delete_candidat)
        edit_button.clicked.connect(self.edit_candidat)
        import_button.clicked.connect(self.import_excel)
        self.load_candidats()

    def load_candidats(self):
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT Candidat.*, Livret_Scolaire.Nombre_de_fois, Livret_Scolaire.Moyenne_6e, 
            Livret_Scolaire.Moyenne_5e, Livret_Scolaire.Moyenne_4e, Livret_Scolaire.Moyenne_3e, 
            Livret_Scolaire.Moyenne_Cycle
            FROM Candidat
            LEFT JOIN Livret_Scolaire ON Candidat.Numero_Table = Livret_Scolaire.Numero_Table
        """)
        candidats = c.fetchall()
        conn.close()

        self.table.setRowCount(len(candidats))
        for row, candidat in enumerate(candidats):
            for col, value in enumerate(candidat):
                if col < 16:  # Ne pas inclure les actions dans le tableau
                    item = QTableWidgetItem(str(value) if value is not None else "")
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    self.table.setItem(row, col, item)

            edit_button = QPushButton("Modifier")
            edit_button.clicked.connect(lambda _, r=row: self.edit_candidat(r))
            delete_button = QPushButton("Supprimer")
            delete_button.clicked.connect(lambda _, r=row: self.delete_candidat(r))

            action_layout = QHBoxLayout()
            action_layout.addWidget(edit_button)
            action_layout.addWidget(delete_button)
            action_widget = QWidget()
            action_widget.setLayout(action_layout)
            self.table.setCellWidget(row, 16, action_widget)

    def import_excel(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Sélectionner le fichier Excel", "",
                                                   "Excel Files (*.xlsx *.xls)")
        if file_name:
            try:
                workbook = openpyxl.load_workbook(file_name)
                sheet = workbook.active

                conn = get_db_connection()
                c = conn.cursor()

                for row in sheet.iter_rows(min_row=2, values_only=True):
                    numero_table, prenom, nom, date_naissance, lieu_naissance, sexe, nb_fois, _, _, nationalite, etat_sportif, epreuve_facultative, moy_6e, moy_5e, moy_4e, moy_3e, note_eps, note_cf, note_ort, note_tsq, note_svt, note_ang1, note_math, note_hg, note_ic, note_pc_lv2, note_ang2, note_ep_fac = row

                    # Convertir la date de naissance en format ISO
                    if date_naissance is None:
                        date_naissance = "2000-01-01"  # Valeur par défaut pour éviter l'erreur
                    elif isinstance(date_naissance, datetime):
                        date_naissance = date_naissance.strftime("%Y-%m-%d")
                    else:
                        date_naissance = datetime.strptime(str(date_naissance), "%d/%m/%Y").strftime("%Y-%m-%d")

                    # Générer un anonymat
                    anonymat = self.generate_anonymat()

                    # Calculer la moyenne du cycle
                    moyennes = [float(m) for m in [moy_6e, moy_5e, moy_4e, moy_3e] if m]
                    moyenne_cycle = sum(moyennes) / len(moyennes) if moyennes else None

                    # Insérer dans la table Candidat
                    c.execute('''INSERT OR REPLACE INTO Candidat 
                                 (Numero_Table, Prenom_s, Nom, Date_Naissance, Lieu_Naissance, Sexe, Nationalite,
                                  Choix_Epr_Facultative, Epreuve_Facultative, Aptitude_Sportive, Anonymat)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                              (numero_table, prenom, nom, date_naissance, lieu_naissance, sexe, nationalite,
                               epreuve_facultative != "NEUTRE", epreuve_facultative, etat_sportif == "APTE", anonymat))

                    # Insérer dans la table Livret_Scolaire
                    c.execute('''INSERT OR REPLACE INTO Livret_Scolaire
                                 (Numero_Table, Nombre_de_fois, Moyenne_6e, Moyenne_5e, Moyenne_4e, Moyenne_3e, Moyenne_Cycle)
                                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
                              (numero_table, nb_fois, moy_6e, moy_5e, moy_4e, moy_3e, moyenne_cycle))

                    # Insérer dans la table Notes
                    c.execute('''INSERT OR REPLACE INTO Notes
                                 (Numero_Table, EPS, Compo_Franc, Dictee, Etude_de_texte, SVT, Anglais1, 
                                  Mathematiques, Histoire_Geographie, Instruction_Civique, PC_LV2, Anglais_Oral, Epreuve_Facultative)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                              (numero_table, note_eps, note_cf, note_ort, note_tsq, note_svt, note_ang1,
                               note_math, note_hg, note_ic, note_pc_lv2, note_ang2, note_ep_fac))

                conn.commit()
                conn.close()

                self.load_candidats()
                QMessageBox.information(self, "Succès", "Importation réussie!")
            except Exception as e:
                QMessageBox.critical(self, "Erreur", f"Une erreur est survenue lors de l'importation : {str(e)}")

    def generate_anonymat(self):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

    def filter_candidates(self):
        search_text = self.search_input.text().lower()
        for row in range(self.table.rowCount()):
            match = False
            for col in range(self.table.columnCount() - 1):  # Exclude the "Actions" column
                item = self.table.item(row, col)
                if item and search_text in item.text().lower():
                    match = True
                    break
            self.table.setRowHidden(row, not match)

    # Les méthodes add_candidat, edit_candidat, et delete_candidat restent inchangées

    # Les méthodes add_candidat, edit_candidat, et delete_candidat restent inchangées

    def load_candidats(self):
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM Candidat")
        candidats = c.fetchall()
        conn.close()

        self.table.setRowCount(len(candidats))
        for row, candidat in enumerate(candidats):
            for col, value in enumerate(candidat):
                if col < 10:  # Ne pas inclure l'anonymat dans le tableau
                    item = QTableWidgetItem(str(value))
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    self.table.setItem(row, col, item)

            edit_button = QPushButton("Modifier")
            edit_button.clicked.connect(lambda _, r=row: self.edit_candidat(r))
            delete_button = QPushButton("Supprimer")
            delete_button.clicked.connect(lambda _, r=row: self.delete_candidat(r))

            action_layout = QHBoxLayout()
            action_layout.addWidget(edit_button)
            action_layout.addWidget(delete_button)
            action_widget = QWidget()
            action_widget.setLayout(action_layout)
            self.table.setCellWidget(row, 10, action_widget)

    def add_candidat(self):
        dialog = CandidatDialog(self)
        if dialog.exec_():
            conn = get_db_connection()
            c = conn.cursor()
            anonymat = self.generate_anonymat()
            c.execute('''INSERT INTO Candidat 
                         (Prenom_s, Nom, Date_Naissance, Lieu_Naissance, Sexe, Nationalite,
                          Choix_Epr_Facultative, Epreuve_Facultative, Aptitude_Sportive, Anonymat)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                      (dialog.prenom_input.text(), dialog.nom_input.text(),
                       dialog.date_naissance_input.date().toString(Qt.ISODate),
                       dialog.lieu_naissance_input.text(), dialog.sexe_input.currentText(),
                       dialog.nationalite_input.text(),
                       dialog.choix_epr_facultative_input.isChecked(),
                       dialog.epreuve_facultative_input.currentText(),
                       dialog.aptitude_sportive_input.isChecked(), anonymat))
            conn.commit()
            conn.close()
            self.load_candidats()

    def edit_candidat(self, row):
        numero_table = self.table.item(row, 0).text()
        dialog = CandidatDialog(self, numero_table)
        if dialog.exec_():
            conn = get_db_connection()
            c = conn.cursor()
            c.execute('''UPDATE Candidat 
                         SET Prenom_s=?, Nom=?, Date_Naissance=?, Lieu_Naissance=?, Sexe=?,
                             Nationalite=?, Choix_Epr_Facultative=?, Epreuve_Facultative=?,
                             Aptitude_Sportive=?
                         WHERE Numero_Table=?''',
                      (dialog.prenom_input.text(), dialog.nom_input.text(),
                       dialog.date_naissance_input.date().toString(Qt.ISODate),
                       dialog.lieu_naissance_input.text(), dialog.sexe_input.currentText(),
                       dialog.nationalite_input.text(),
                       dialog.choix_epr_facultative_input.isChecked(),
                       dialog.epreuve_facultative_input.currentText(),
                       dialog.aptitude_sportive_input.isChecked(), numero_table))
            conn.commit()
            conn.close()
            self.load_candidats()

    def delete_candidat(self, row):
        numero_table = self.table.item(row, 0).text()
        reply = QMessageBox.question(self, "Confirmation",
                                     f"Êtes-vous sûr de vouloir supprimer le candidat n°{numero_table} ?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("DELETE FROM Candidat WHERE Numero_Table=?", (numero_table,))
            conn.commit()
            conn.close()
            self.load_candidats()

    def generate_anonymat(self):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

    def filter_candidates(self):
        search_text = self.search_input.text().lower()
        for row in range(self.table.rowCount()):
            match = False
            for col in range(self.table.columnCount() - 1):  # Exclude the "Actions" column
                item = self.table.item(row, col)
                if item and search_text in item.text().lower():
                    match = True
                    break
            self.table.setRowHidden(row, not match)


class CandidatDialog(QDialog):
    def __init__(self, parent=None, numero_table=None):
        super().__init__(parent)
        self.setWindowTitle("Ajouter/Modifier un Candidat")
        layout = QFormLayout()

        self.prenom_input = QLineEdit()
        self.nom_input = QLineEdit()
        self.date_naissance_input = QDateEdit()
        self.lieu_naissance_input = QLineEdit()
        self.sexe_input = QComboBox()
        self.sexe_input.addItems(["M", "F"])
        self.nationalite_input = QLineEdit()
        self.choix_epr_facultative_input = QCheckBox()
        self.epreuve_facultative_input = QComboBox()
        self.epreuve_facultative_input.addItems(["Couture", "Dessin", "Musique"])
        self.aptitude_sportive_input = QCheckBox()

        # Ajout de validations
        self.prenom_input.setValidator(QRegExpValidator(QRegExp(r"[A-Za-z\s]+")))
        self.nom_input.setValidator(QRegExpValidator(QRegExp(r"[A-Za-z\s]+")))
        self.lieu_naissance_input.setValidator(QRegExpValidator(QRegExp(r"[A-Za-z\s]+")))
        self.nationalite_input.setValidator(QRegExpValidator(QRegExp(r"[A-Za-z\s]+")))

        layout.addRow("Prénom(s):", self.prenom_input)
        layout.addRow("Nom:", self.nom_input)
        layout.addRow("Date de Naissance:", self.date_naissance_input)
        layout.addRow("Lieu de Naissance:", self.lieu_naissance_input)
        layout.addRow("Sexe:", self.sexe_input)
        layout.addRow("Nationalité:", self.nationalite_input)
        layout.addRow("Choix Épreuve Facultative:", self.choix_epr_facultative_input)
        layout.addRow("Épreuve Facultative:", self.epreuve_facultative_input)
        layout.addRow("Aptitude Sportive:", self.aptitude_sportive_input)

        buttons = QHBoxLayout()
        save_button = QPushButton("Enregistrer")
        save_button.clicked.connect(self.accept)
        cancel_button = QPushButton("Annuler")
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addRow(buttons)

        self.setLayout(layout)

        if numero_table:
            self.load_candidat(numero_table)

    def load_candidat(self, numero_table):
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM Candidat WHERE Numero_Table=?", (numero_table,))
        candidat = c.fetchone()
        conn.close()

        if candidat:
            self.prenom_input.setText(candidat[1])
            self.nom_input.setText(candidat[2])
            self.date_naissance_input.setDate(QDate.fromString(candidat[3], Qt.ISODate))
            self.lieu_naissance_input.setText(candidat[4])
            self.sexe_input.setCurrentText(candidat[5])
            self.nationalite_input.setText(candidat[6])
            self.choix_epr_facultative_input.setChecked(candidat[7])
            self.epreuve_facultative_input.setCurrentText(candidat[8])
            self.aptitude_sportive_input.setChecked(candidat[9])

    def accept(self):
        if not self.prenom_input.text() or not self.nom_input.text():
            QMessageBox.warning(self, "Erreur", "Le prénom et le nom sont obligatoires.")
            return
        if not self.date_naissance_input.date().isValid():
            QMessageBox.warning(self, "Erreur", "La date de naissance n'est pas valide.")
            return
        super().accept()