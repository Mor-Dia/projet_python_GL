import sqlite3
from PyQt5.QtWidgets import QMessageBox

def handle_db_error(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except sqlite3.Error as e:
            QMessageBox.critical(None, "Erreur de base de données", f"Une erreur est survenue : {str(e)}")
    return wrapper

@handle_db_error
def create_database():
    conn = sqlite3.connect('bfem.db')
    c = conn.cursor()

    # Création de la table Jury
    c.execute('''CREATE TABLE IF NOT EXISTS Jury
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ia TEXT,
                  ief TEXT,
                  localite TEXT,
                  centre_examen TEXT,
                  president_jury TEXT,
                  telephone TEXT)''')

    # Création de la table Candidat
    c.execute('''CREATE TABLE IF NOT EXISTS Candidat
                 (Numero_Table INTEGER PRIMARY KEY,
                  Prenom_s TEXT,
                  Nom TEXT,
                  Date_Naissance DATE,
                  Lieu_Naissance TEXT,
                  Sexe TEXT,
                  Nationalite TEXT,
                  Choix_Epr_Facultative BOOLEAN,
                  Epreuve_Facultative TEXT,
                  Aptitude_Sportive BOOLEAN,
                  Anonymat TEXT)''')

    # Création de la table Livret_Scolaire
    c.execute('''CREATE TABLE IF NOT EXISTS Livret_Scolaire
                 (Numero_Table INTEGER PRIMARY KEY,
                  Nombre_de_fois INTEGER,
                  Moyenne_6e REAL,
                  Moyenne_5e REAL,
                  Moyenne_4e REAL,
                  Moyenne_3e REAL,
                  Moyenne_Cycle REAL,
                  FOREIGN KEY (Numero_Table) REFERENCES Candidat(Numero_Table))''')

    # Création de la table Notes
    c.execute('''CREATE TABLE IF NOT EXISTS Notes
                 (Numero_Table INTEGER PRIMARY KEY,
                  Compo_Franc REAL,
                  Dictee REAL,
                  Etude_de_texte REAL,
                  Instruction_Civique REAL,
                  Histoire_Geographie REAL,
                  Mathematiques REAL,
                  PC_LV2 REAL,
                  SVT REAL,
                  Anglais1 REAL,
                  Anglais_Oral REAL,
                  EPS REAL,
                  Epreuve_Facultative REAL,
                  Total_Points REAL,
                  Moyenne REAL,
                  FOREIGN KEY (Numero_Table) REFERENCES Candidat(Numero_Table))''')

    # Création de la table Notes_Second_Tour
    c.execute('''CREATE TABLE IF NOT EXISTS Notes_Second_Tour
                 (Numero_Table INTEGER PRIMARY KEY,
                  Francais REAL,
                  Mathematiques REAL,
                  PC_LV2 REAL,
                  FOREIGN KEY (Numero_Table) REFERENCES Candidat(Numero_Table))''')

    # Création de la table Deliberation
    c.execute('''CREATE TABLE IF NOT EXISTS Deliberation
                 (Numero_Table INTEGER PRIMARY KEY,
                  Decision TEXT,
                  FOREIGN KEY (Numero_Table) REFERENCES Candidat(Numero_Table))''')

    conn.commit()
    conn.close()

@handle_db_error
def get_db_connection():
    return sqlite3.connect('bfem.db')