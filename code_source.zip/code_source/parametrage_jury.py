from PyQt5.QtWidgets import QWidget, QFormLayout, QLineEdit, QPushButton, QMessageBox
from database import get_db_connection

class ParametrageJuryTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QFormLayout()

        self.ia_input = QLineEdit()
        self.ief_input = QLineEdit()
        self.localite_input = QLineEdit()
        self.centre_examen_input = QLineEdit()
        self.president_jury_input = QLineEdit()
        self.telephone_input = QLineEdit()

        layout.addRow("IA (Région):", self.ia_input)
        layout.addRow("IEF (Département):", self.ief_input)
        layout.addRow("Localité:", self.localite_input)
        layout.addRow("Centre d'Examen:", self.centre_examen_input)
        layout.addRow("Président de Jury:", self.president_jury_input)
        layout.addRow("Téléphone:", self.telephone_input)

        save_button = QPushButton("Enregistrer")
        save_button.clicked.connect(self.save_parametrage)
        layout.addRow(save_button)

        self.setLayout(layout)
        self.load_parametrage()

    def save_parametrage(self):
        conn = get_db_connection()
        c = conn.cursor()
        
        c.execute('''INSERT OR REPLACE INTO Jury 
                     (id, ia, ief, localite, centre_examen, president_jury, telephone) 
                     VALUES (1, ?, ?, ?, ?, ?, ?)''', 
                  (self.ia_input.text(), self.ief_input.text(), self.localite_input.text(),
                   self.centre_examen_input.text(), self.president_jury_input.text(),
                   self.telephone_input.text()))
        
        conn.commit()
        conn.close()
        
        QMessageBox.information(self, "Succès", "Paramètres du jury enregistrés avec succès.")

    def load_parametrage(self):
        conn = get_db_connection()
        c = conn.cursor()
        
        c.execute("SELECT * FROM Jury WHERE id = 1")
        jury = c.fetchone()
        
        if jury:
            self.ia_input.setText(jury[1])
            self.ief_input.setText(jury[2])
            self.localite_input.setText(jury[3])
            self.centre_examen_input.setText(jury[4])
            self.president_jury_input.setText(jury[5])
            self.telephone_input.setText(jury[6])
        
        conn.close()