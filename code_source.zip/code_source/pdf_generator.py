import os
from tkinter import filedialog
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from database import get_db_connection

def choisir_emplacement_fichier(nom_fichier):
    """Ouvre une boîte de dialogue pour choisir où enregistrer le fichier PDF."""
    return filedialog.asksaveasfilename(defaultextension=".pdf", initialfile=nom_fichier, 
                                        filetypes=[("Fichiers PDF", "*.pdf")])

def generer_pdf(nom_fichier, titre, requete_sql, colonnes):
    """Génère un PDF à partir des données extraites de la base de données."""
    chemin_fichier = choisir_emplacement_fichier(nom_fichier)
    if not chemin_fichier:
        print("Génération annulée.")
        return

    try:
        with get_db_connection() as conn:
            c = conn.cursor()
            c.execute(requete_sql)
            donnees = c.fetchall()


        doc = SimpleDocTemplate(chemin_fichier, pagesize=letter)
        elements = []

        styles = getSampleStyleSheet()
        elements.append(Paragraph(titre, styles['Title']))

        data = [colonnes] + donnees  # Ajouter les en-têtes
        table = Table(data)

        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 12),
            ('TOPPADDING', (0, 1), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))

        elements.append(table)
        doc.build(elements)
        print(f"PDF généré avec succès : {chemin_fichier}")

    except Exception as e:
        print(f"Erreur lors de la génération du PDF : {e}")

def generer_liste_candidats():
    generer_pdf("liste_candidats.pdf", "Liste des Candidats",
                "SELECT Numero_Table, Prenom_s, Nom, Date_Naissance, Lieu_Naissance, Sexe FROM Candidat",
                ['N° Table', 'Prénom(s)', 'Nom', 'Date de Naissance', 'Lieu de Naissance', 'Sexe'])

def generer_liste_anonymats():
    generer_pdf("liste_anonymats.pdf", "Liste des Anonymats",
                "SELECT Numero_Table, Anonymat FROM Candidat",
                ['N° Table', 'Anonymat'])

def generer_resultats():
    generer_pdf("resultats.pdf", "Résultats des Candidats",
                """SELECT Candidat.Numero_Table, Candidat.Prenom_s, Candidat.Nom, 
                          Notes.Total_Points, Notes.Moyenne, Deliberation.Decision
                   FROM Candidat
                   JOIN Notes ON Candidat.Numero_Table = Notes.Numero_Table
                   JOIN Deliberation ON Candidat.Numero_Table = Deliberation.Numero_Table""",
                ['N° Table', 'Prénom(s)', 'Nom', 'Total Points', 'Moyenne', 'Décision'])

def generer_pv_deliberations():
    generer_pdf("pv_deliberations.pdf", "Procès-Verbal de Délibérations",
                """SELECT Candidat.Numero_Table, Candidat.Prenom_s, Candidat.Nom, 
                          Notes.Total_Points, Notes.Moyenne, Deliberation.Decision
                   FROM Candidat
                   JOIN Notes ON Candidat.Numero_Table = Notes.Numero_Table
                   JOIN Deliberation ON Candidat.Numero_Table = Deliberation.Numero_Table""",
                ['N° Table', 'Prénom(s)', 'Nom', 'Total Points', 'Moyenne', 'Décision'])

def generer_releve_notes_individuel(tour):
    conn = get_db_connection()
    c = conn.cursor()

    # Requête SQL en fonction du tour
    if tour == 1:
        c.execute("""
            SELECT Candidat.Numero_Table, Candidat.Prenom_s, Candidat.Nom, 
                   Notes.Compo_Franc, Notes.Dictee, Notes.Etude_de_texte, 
                   Notes.Instruction_Civique, Notes.Histoire_Geographie, 
                   Notes.Mathematiques, Notes.PC_LV2, Notes.SVT, 
                   Notes.Anglais1, Notes.Anglais_Oral, Notes.EPS, 
                   Notes.Epreuve_Facultative, Notes.Total_Points, Notes.Moyenne
            FROM Candidat
            JOIN Notes ON Candidat.Numero_Table = Notes.Numero_Table
        """)
    else:
        c.execute("""
            SELECT Candidat.Numero_Table, Candidat.Prenom_s, Candidat.Nom, 
                   Notes_Second_Tour.Francais, Notes_Second_Tour.Mathematiques, 
                   Notes_Second_Tour.PC_LV2, Notes_Second_Tour.Total_Points, 
                   Notes_Second_Tour.Moyenne
            FROM Candidat
            JOIN Notes_Second_Tour ON Candidat.Numero_Table = Notes_Second_Tour.Numero_Table
        """)

    candidats = c.fetchall()
    conn.close()

    # Parcours de chaque candidat pour générer un fichier PDF individuel
    coefficients = [2, 1, 1, 1, 2, 4, 2, 2, 2, 1, 1, 1] if tour == 1 else [3, 3, 2]

    for candidat in candidats:
        numero_table, prenoms, nom, *notes = candidat
        total_points = notes[-2] if notes[-2] is not None else 0.00
        moyenne = notes[-1] if notes[-1] is not None else 0.00
        if total_points == 0.00:
            total_points = sum(note * coef for note, coef in zip(notes[:-2], coefficients) if note is not None)

        if moyenne == 0.00:
            # Gestion du bonus/malus EPS
            if len(notes) > 10 and notes[10] is not None:
                total_points += (notes[10] - 10) if notes[10] > 10 else -(10 - notes[10])

            # Gestion du bonus épreuve facultative
            if len(notes) > 11 and notes[11] is not None and notes[11] > 10:
                total_points += notes[11] - 10
            moyenne =(total_points/18) # Remplace 20 par le total des coefficients

        pdf_filename = f"releve_notes_{numero_table}.pdf"
        doc = SimpleDocTemplate(pdf_filename, pagesize=letter)
        elements = []

        styles = getSampleStyleSheet()
        title = f"Relevé de Notes - {tour}er Tour"
        elements.append(Paragraph(title, styles['Title']))

        # Ajout des informations du candidat
        info_candidat = [
            ["Numéro de Table :", numero_table],
            ["Nom :", nom],
            ["Prénom(s) :", prenoms]
        ]
        table_info = Table(info_candidat, colWidths=[150, 300])
        table_info.setStyle(TableStyle([
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
        ]))
        elements.append(table_info)

        # Ajout des notes
        if tour == 1:
            matieres = ['Compo. Française', 'Dictée', 'Etude de texte', 'Instruction Civique',
                        'Histoire-Géo', 'Mathématiques', 'PC/LV2', 'SVT',
                        'Anglais 1', 'Anglais (Oral)', 'EPS', 'Epreuve Facultative']
        else:
            matieres = ['Français', 'Mathématiques', 'PC/LV2']

        data = [['Matière', 'Note']] + [[matieres[i], notes[i]] for i in range(len(matieres))]

        table_notes = Table(data, colWidths=[250, 100])
        table_notes.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 12),
            ('TOPPADDING', (0, 1), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(table_notes)

        # Ajout du total des points et moyenne
        recapitulatif = [
            ["Total des Points :", f"{total_points:.2f}"],
            ["Moyenne :", f"{moyenne:.2f}"]
        ]
        table_recap = Table(recapitulatif, colWidths=[250, 100])
        table_recap.setStyle(TableStyle([
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(table_recap)

        # Génération du fichier PDF
        doc.build(elements)
        print(f"✔️ Relevé généré pour {prenoms} {nom} : {pdf_filename}")
        if total_points == 0.00 or moyenne == 0.00:
            print(
                f"⚠️ Attention : Les points et la moyenne du candidat {numero_table} ne sont pas enregistrés en base.")

