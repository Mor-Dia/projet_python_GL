import unittest
from database import get_db_connection, create_database
from gui.tabs.gestion_candidats import CandidatDialog
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QDate
import sys

class TestDatabase(unittest.TestCase):
    def setUp(self):
        create_database()
        self.conn = get_db_connection()
        self.cursor = self.conn.cursor()

    def tearDown(self):
        self.conn.close()

    def test_create_tables(self):
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = self.cursor.fetchall()
        expected_tables = ['Jury', 'Candidat', 'Livret_Scolaire', 'Notes', 'Notes_Second_Tour', 'Deliberation']
        self.assertEqual(set([table[0] for table in tables]), set(expected_tables))

class TestCandidatDialog(unittest.TestCase):
    def setUp(self):
        self.app = QApplication(sys.argv)

    def test_candidat_dialog_validation(self):
        dialog = CandidatDialog()
        dialog.prenom_input.setText("John")
        dialog.nom_input.setText("Doe")
        dialog.date_naissance_input.setDate(QDate(2000, 1, 1))
        self.assertTrue(dialog.accept())

        dialog.prenom_input.setText("")
        self.assertFalse(dialog.accept())

if __name__ == '__main__':
    unittest.main()